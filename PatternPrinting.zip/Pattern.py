def oddPattern(n):
	
# Top Pyramid
	# Spaces and value count for first line
	spaces = n//2
	value = 0
	
	for i in range(0, n, 2):
		value = 1
		for j in range(0, spaces):
			print(end=" ")
		spaces = spaces - 1
		for j in range(0, i + 1):
			print(value, end="")
			value += 1
		print("\r")
	

# Bottom Pyramid
	# Spaces and value count for first line of bottom pyramid
	spaces = 1
	value = n
	
	for i in range(n-2, -1, -2):
		value = 1
		for j in range(spaces, 0, -1):
			print(end=" ")
		spaces += 1
		for j in range(0, i):
			print(value, end="")
			value+=1
		print("\r")

def evenPattern(n):
	
# Top Pyramid
	# Spaces and value count for first line
	spaces = n//2
	value = 0
	
	for i in range(0, n, 2):
		value = 1
		
		for j in range(0, spaces):
			print(end=" ")
		
		spaces = spaces - 1
		
		for j in range(0, i + 1):
			print(value, end="")
			value += 1
		
		print("\r")
	

# Bottom Pyramid
	# Spaces and value count for first line of bottom pyramid
	spaces = 1
	value = n
	
	for i in range(n-1, -1, -2):
		value = 1

		for j in range(spaces, 0, -1):
			print(end=" ")
		
		spaces += 1

		for j in range(0, i):
			print(value, end="")
			value+=1
		
		print("\r")


if __name__ == '__main__':
	n = int(input("Enter a number: "))

	if n%2==0:
		evenPattern(n)
	else:
		oddPattern(n)
