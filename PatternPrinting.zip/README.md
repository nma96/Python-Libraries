Instructions:

For Mac:

1. Open terminal and file location
2. Run command: python3 Pattern.py


For Windows: 

1. Open command prompt and cd to file location
2. Run command: py Pattern.py